def match_skills(resume_skills, job_skills):
    resume = set(resume_skills)
    job = set(job_skills)

    matched = sorted(resume & job)
    missing = sorted(job - resume)

    score = round((len(matched) / len(job)) * 100, 2) if job else 0.0
    return score, matched, missing
