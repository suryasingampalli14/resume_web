import re

SKILLS = [
    "python", "r", "sql", "machine learning", "deep learning",
    "pandas", "numpy", "tensorflow", "scikit-learn",
    "html", "css", "javascript",
    "git", "docker", "flask", "django",
    "seo", "content marketing", "social media",
    "google analytics", "email marketing", "advertising",
    "brand strategy", "copywriting",
    "figma", "adobe xd", "sketch",
    "wireframing", "prototyping", "user research", "design thinking",
    "c", "c++", "java","power bi","ms office","customer relationship management","google workspace",
    "adaptability","communication & teamwork","customer handling"
]

def extract_skills(text):
    text = text.lower()
    found = set()

    for skill in SKILLS:
        if re.search(rf"\b{re.escape(skill)}\b", text):
            found.add(skill)

    return list(found)
