import os
import sys
from flask import Flask, render_template, request

# Allow imports from src folder
sys.path.append(os.path.dirname(__file__))

from resume_parser import extract_text
from skill_extractor import extract_skills
from matcher import match_skills

# ----------------------------
# Job roles & skills (ALL LOWERCASE)
# ----------------------------
JOB_SKILLS = {
    "Data Scientist": [
        "python", "r", "sql", "machine learning",
        "deep learning", "pandas", "numpy",
        "tensorflow", "scikit-learn"
    ],
    "Software Developer": [
        "python", "java", "c", "c++", "git",
        "rest api", "html", "css", "javascript",
        "sql", "docker", "flask", "django"
    ],
    "Marketing": [
        "seo", "content marketing", "social media",
        "google analytics", "email marketing",
        "advertising", "brand strategy", "copywriting","power bi","ms office","customer relationship management","google workspace",
        "adaptability","communication & teamwork","customer handling"
    ],
    "UI/UX Designer": [
        "figma", "adobe xd", "sketch",
        "wireframing", "prototyping",
        "user research", "design thinking"
    ]
}

# ----------------------------
# Flask setup
# ----------------------------
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

app = Flask(
    __name__,
    template_folder=os.path.join(BASE_DIR, "templates"),
    static_folder=os.path.join(BASE_DIR, "static")
)

UPLOAD_FOLDER = os.path.join(BASE_DIR, "data", "resumes")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

# ----------------------------
# Routes
# ----------------------------
@app.route("/", methods=["GET", "POST"])
def index():
    score = matched = missing = None

    if request.method == "POST":
        role = request.form.get("role")
        job_skills = JOB_SKILLS.get(role, [])

        file = request.files.get("resume")
        if file and file.filename:
            path = os.path.join(app.config["UPLOAD_FOLDER"], file.filename)
            file.save(path)

            resume_text = extract_text(path)
            resume_skills = extract_skills(resume_text)

            print("RESUME SKILLS:", resume_skills)
            print("JOB SKILLS:", job_skills)

            score, matched, missing = match_skills(resume_skills, job_skills)

    return render_template(
        "index.html",
        roles=JOB_SKILLS.keys(),
        score=score,
        matched=matched,
        missing=missing
    )

# ----------------------------
# Run server
# ----------------------------
if __name__ == "__main__":
    app.run(debug=True, port=3000)